<div id="menu">
	<ul>
		<li><a href="<?php echo base_url(); ?>dosen/">Beranda</a></li>
		<li><a href="<?php echo base_url(); ?>dosen/persetujuan">Persetujuan KRS</a></li>
		<li><a href="<?php echo base_url(); ?>dosen/nilai">Input Nilai</a></li>
		<li><a href="<?php echo base_url(); ?>dosen/akun">Pengaturan Akun</a></li>
		<li><a href="<?php echo base_url(); ?>web/logout">Keluar</a></li>
	</ul>
	<div class="cleaner_h0"></div>
</div>