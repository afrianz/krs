<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $judul; ?></title>
	<link href="<?php echo base_url(); ?>asset/css/style.css" rel="stylesheet">
</head>
<body>