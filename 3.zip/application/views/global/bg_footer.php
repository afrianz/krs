

	<p class="footer">
	Sistem Informasi Akademik Online 2012 - Gede Lumbung (http://gedelumbung.com)<br />
	Halaman ini dimuat selama <strong>{elapsed_time}</strong> detik
	</p>
</div>
</body>
</html>