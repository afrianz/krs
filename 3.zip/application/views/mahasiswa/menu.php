<div id="menu">
	<ul>
		<li><a href="<?php echo base_url(); ?>mahasiswa/">Beranda</a></li>
		<li><a href="<?php echo base_url(); ?>mahasiswa/krs">Kartu Rencana Studi</a></li>
		<li><a href="<?php echo base_url(); ?>mahasiswa/khs">Kartu Hasil Studi</a></li>
		<li><a href="<?php echo base_url(); ?>mahasiswa/info_kampus">Info Kampus</a></li>
		<li><a href="<?php echo base_url(); ?>mahasiswa/akun">Pengaturan Akun</a></li>
		<li><a href="<?php echo base_url(); ?>web/logout">Keluar</a></li>
	</ul>
	<div class="cleaner_h0"></div>
</div>