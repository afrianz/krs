<p>Selamat Datang <strong>
<?php echo $nama; ?></strong>, anda login sebagai 
<strong><?php echo $status; ?></strong> dengan nim  
<strong><?php echo $nim; ?></strong>.</p>