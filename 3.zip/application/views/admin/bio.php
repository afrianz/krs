<p>Selamat Datang <strong>
<?php echo $nama; ?></strong>, anda login sebagai 
<strong><?php echo $status; ?></strong> dengan username  
<strong><?php echo $username; ?></strong>.</p>