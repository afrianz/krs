<div id="container">
	<h1>Beranda - Sistem Informasi Akademik Online</h1>

	<div id="body">
		<?php
			echo $bio;
			echo $menu;
		?>
		
		<p>
		Selamat Datang di Sistem Perwalian Intranet Online STIKOM PGRI Banyuwangi.
Setelah melakukan login pertama kali ke Sistem Perwalian Intranet Online ini, harap segera melakukan pergantian password pada menu Pengaturan Akun, guna menanggulangi hal-hal yang tidak diinginkan.
		</p>
		
		<div id="list">
			<ul>
				<li><strong>Persetujuan Kartu Rencana Studi KRS</strong><br />Untuk Melakukan Persetujuan KRS Pada Mahasiswa Yang Dibimbing</li>
				<li><strong>Daftar Mahasiswa Bimbingan</strong><br />Melihat daftar mahasiswa yang masuk dalam bimbingan Dosen PA</li>
				<li><strong>Nilai Mahasiswa</strong><br />Mengisi nilai mahasiswa yang dibimbing</li>
				<li><strong>Log Out</strong><br />Keluar dari sistem perwalian online</li>
			</ul>
		</div>
		
	</div>
