<div id="menu">
	<ul>
		<li><a href="<?php echo base_url(); ?>dosen/">Beranda</a></li>
		<li><a href="<?php echo base_url(); ?>admin/tampil_jadwal">Jadwal Perkuliahan</a></li>
		<li><a href="<?php echo base_url(); ?>admin/nilai">Nilai</a></li>
		<li><a href="<?php echo base_url(); ?>admin/dosen">Dosen</a></li>
		<li><a href="<?php echo base_url(); ?>admin/mk">Mata Kuliah</a></li>
		<li><a href="<?php echo base_url(); ?>admin/mahasiswa">Mahasiswa</a></li>
		<li><a href="<?php echo base_url(); ?>admin/info">Info Kampus</a></li>
		<li><a href="<?php echo base_url(); ?>admin/akun">Pengaturan Akun</a></li>
		<li><a href="<?php echo base_url(); ?>web/logout">Keluar</a></li>
	</ul>
	<div class="cleaner_h0"></div>
</div>