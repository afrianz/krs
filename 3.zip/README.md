Sistem Perwalian Online
======
Sistem kartu rencana studi online berbasis web, dibuat dengan menggunakan Codeigniter 2.1*.

####Kebutuhan Sistem
1.	PHP 5.2*
2.	MySQL 5.*
3.	Apache 2.*

####Cara Install
1.	Clone atau Download Zip
2.	Copy ke htdocs
3.	Buat database baru & import file krs.sql
4.	Sesuaikan konfigurasi database di file application/config/database.php